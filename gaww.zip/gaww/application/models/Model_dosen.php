<?php
class Model_dosen extends CI_Model 
{
    public function getAllDosen()
    { 
        return $query = $this->db->get('dosen')->result_array();
    }

    public function Tambahdosen()
    {
        $data = [
            "dosen" => $this->input->post('dosen', true)
        ];

        $this->db->insert('dosen', $data);
    }

    public function Ubahdosen()
    {
        $data = [
            "dosen" => $this->input->post('dosen', true)
        ];

        $this->db->where('id', $this->input->post('id'));
        $this->db->update('dosen', $data);
    }

    public function hapusdosen($id)       
    {
        $this->db->where('id', $id);
        $this->db->delete('dosen');
    }

    public function getDosenById($id)
    {
        return $this->db->get_where('dosen', ['id' => $id])->row_array();
    }

    public function Caridosen()
    {
        $keyword = $this->input->post('keyword', true);
        $this->db->like('dosen', $keyword);
        return $this->db->get('dosen')->result_array();
    }
}

?>