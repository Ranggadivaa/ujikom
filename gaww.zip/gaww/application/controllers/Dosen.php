<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dosen extends CI_Controller {

    public function __construct()
	{
		parent::__construct();
		$this->load->library('form_validation');
        $this->load->model('Model_dosen');
        if(!$this->session->userdata('username')) {
            redirect('auth');
        }
    }

    public function index()
    {
        $data['title'] = 'Dosen';

        $data['dosen'] = $this->Model_dosen->getAllDosen();
        if( $this->input->post('keyword') ) {
            $data['dosen'] = $this->Model_dosen->Caridosen();
        }
        $this->load->view('templates/header.php', $data);
        $this->load->view('dosen/index.php', $data);
        $this->load->view('templates/footer.php');
    }

    public function tambah()
    {
        $this->form_validation->set_rules('dosen', 'Dosen', 'trim|required');

        if($this->form_validation->run() == false ) {
            $data['title'] = 'Tambah Dosen';

            $this->load->view('templates/header.php', $data);
            $this->load->view('dosen/tambah.php', $data);
            $this->load->view('templates/footer.php');
        } else {
            $this->Model_dosen->TambahDosen();
            $this->session->set_flashdata('flash', 'Ditambahkan');
            redirect('dosen');
        }
        
    }

    public function ubah($id)
    {
        $this->form_validation->set_rules('dosen', 'Dosen', 'trim|required');
        $data['dosen'] = $this->Model_dosen->getDosenById($id);

        if($this->form_validation->run() == false ) {
            $data['title'] = 'Ubah dosen';

            $this->load->view('templates/header.php', $data);
            $this->load->view('dosen/ubah.php', $data);
            $this->load->view('templates/footer.php');
        } else {
            $this->Model_dosen->Ubahdosen();
            $this->session->set_flashdata('flash', 'Diubah');
            redirect('dosen');
        }
        
    }

    public function hapus($id)
    {
        $this->Model_dosen->hapusDosen($id);
        $this->session->set_flashdata('flash', 'Dihapus');
        redirect('dosen');
    }
}
