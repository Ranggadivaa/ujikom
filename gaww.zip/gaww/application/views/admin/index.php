<div class="container">
    <h1>Welcome to IPB University</h1>
</div>
<div id="carouselExampleAutoplaying" class="carousel slide" data-bs-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="https://awsimages.detik.net.id/community/media/visual/2018/01/17/4c003a60-7b3f-452b-a719-9d84fb489e79_169.jpeg?w=700&q=90" class="d-block w-100" alt="10px">
    </div>
    <div class="carousel-item">
      <img src="https://asset.kompas.com/crops/0_QvTlosK6p0YsVgFyqHenTXURY=/0x0:1024x683/750x500/data/photo/2020/04/07/5e8bd54441f9f.jpg" class="d-block w-100" alt="10px">
    </div>
    <div class="carousel-item">
      <img src="https://img.okezone.com/content/2022/06/17/65/2613085/ipb-university-jadi-satu-satunya-kampus-di-indonesia-yang-masuk-ranking-dunia-bidang-lingkungan-sAyIIQ346y.jpg" class="d-block w-100" alt="...">
    </div>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleAutoplaying" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleAutoplaying" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>