<div class="container">
    <form action="" method="post">
        <legend>Ubah Data Dosen</legend>
        <div class="mb-3">
            <input type="hidden" name="id" value="<?= $dosen['id']; ?>">
            <label for="dosen" class="form-label">Nama Dosen</label>
            <input type="text" class="form-control" id="dosen" name="dosen" value="<?= $dosen['dosen']; ?>" style="width : 300px;">
            <div class="form-text text-danger"><?= form_error('dosen'); ?></div>
        </div>
        <input type="submit" name="ubah" value="ubah" class="btn btn-primary"></input>
    </form>
</div>